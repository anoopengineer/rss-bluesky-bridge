use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, PartialEq)]
pub struct RssItem {
    pub guid: String,
    pub title: String,
    pub description: String,
    pub link: String,
    pub pub_date: String,
}

// Add more shared types and functions as needed

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn test_rss_item_serialization() {
        let item = RssItem {
            guid: "123".to_string(),
            title: "Test".to_string(),
            description: "Description".to_string(),
            link: "http://example.com".to_string(),
            pub_date: "2023-04-01".to_string(),
        };
        let serialized = serde_json::to_string(&item).unwrap();
        let deserialized: RssItem = serde_json::from_str(&serialized).unwrap();
        assert_eq!(item, deserialized);
    }

    // Add more unit tests as needed
}
